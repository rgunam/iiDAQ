var searchData=
[
  ['copyright_102',['Copyright',['../page_copyright.html',1,'index']]]
];
