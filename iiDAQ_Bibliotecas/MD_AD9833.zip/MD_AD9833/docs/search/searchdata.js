var indexSectionsWithContent =
{
  0: "abcgmprs~",
  1: "m",
  2: "m",
  3: "bgmrs~",
  4: "a",
  5: "cm",
  6: "cm",
  7: "ap",
  8: "acrs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Pages"
};

