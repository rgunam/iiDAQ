var searchData=
[
  ['setactivefrequency_64',['setActiveFrequency',['../class_m_d___a_d9833.html#a959b40e8914d47343e24c002169c7cfe',1,'MD_AD9833']]],
  ['setactivephase_65',['setActivePhase',['../class_m_d___a_d9833.html#a0b64736e63aa654bede19358cca3588c',1,'MD_AD9833']]],
  ['setfrequency_66',['setFrequency',['../class_m_d___a_d9833.html#a8c441358f85c08270271603c4bd698a3',1,'MD_AD9833']]],
  ['setmode_67',['setMode',['../class_m_d___a_d9833.html#a57b4c240384f25a9bc06a65d5d1901e7',1,'MD_AD9833']]],
  ['setphase_68',['setPhase',['../class_m_d___a_d9833.html#a6cffbcec042d5eee2a18b84c5ce25552',1,'MD_AD9833']]]
];
