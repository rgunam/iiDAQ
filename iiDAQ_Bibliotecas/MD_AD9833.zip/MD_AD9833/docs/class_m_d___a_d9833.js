var class_m_d___a_d9833 =
[
    [ "channel_t", "class_m_d___a_d9833.html#ac870bc23df74953917354b3b0ba2e98c", [
      [ "CHAN_0", "class_m_d___a_d9833.html#ac870bc23df74953917354b3b0ba2e98ca5f69427f0fe4cc722f9041b939ac28f8", null ],
      [ "CHAN_1", "class_m_d___a_d9833.html#ac870bc23df74953917354b3b0ba2e98ca64b7e1ac371a2bb8069d6d6a8e970c8d", null ]
    ] ],
    [ "mode_t", "class_m_d___a_d9833.html#a0af29b0bc3883ccd8b5150bce814dfa0", [
      [ "MODE_OFF", "class_m_d___a_d9833.html#a0af29b0bc3883ccd8b5150bce814dfa0adf3381086d391126bc76ff5c92144657", null ],
      [ "MODE_SINE", "class_m_d___a_d9833.html#a0af29b0bc3883ccd8b5150bce814dfa0ad7a4ab52bb1bee0ce39b7b54644a029d", null ],
      [ "MODE_SQUARE1", "class_m_d___a_d9833.html#a0af29b0bc3883ccd8b5150bce814dfa0a1a70af5aaa0d5270e739146befbcc2c1", null ],
      [ "MODE_SQUARE2", "class_m_d___a_d9833.html#a0af29b0bc3883ccd8b5150bce814dfa0aa40b5a6a51100ac0d1b926afe07bbfa6", null ],
      [ "MODE_TRIANGLE", "class_m_d___a_d9833.html#a0af29b0bc3883ccd8b5150bce814dfa0ae9c6b923a1b928aed747df397b3f7903", null ]
    ] ],
    [ "MD_AD9833", "class_m_d___a_d9833.html#a92d53cd8ed35472088801854d80cd4be", null ],
    [ "MD_AD9833", "class_m_d___a_d9833.html#a867b6ad0cdb2412d6b34206b81fedc3e", null ],
    [ "~MD_AD9833", "class_m_d___a_d9833.html#af667a5a6fa1be07d44e3b516cdcff0c8", null ],
    [ "begin", "class_m_d___a_d9833.html#a9b5f5ad39d22af155c6fd85dcec7cf89", null ],
    [ "getActiveFrequency", "class_m_d___a_d9833.html#a947eef2d0f5ccb8e56441b741f1d7487", null ],
    [ "getActivePhase", "class_m_d___a_d9833.html#ab8663778999fd5b1262f7f2661bd4bb9", null ],
    [ "getFrequency", "class_m_d___a_d9833.html#a592ebc9c1c8a63496d9e6941818e6965", null ],
    [ "getMode", "class_m_d___a_d9833.html#a18b799d4b2f1162bfcd68a2c81f6c571", null ],
    [ "getPhase", "class_m_d___a_d9833.html#aa825c7a6896ba1fc1a2b2943053f8336", null ],
    [ "reset", "class_m_d___a_d9833.html#a31bdf3f3366d336c46787284c9262c1a", null ],
    [ "setActiveFrequency", "class_m_d___a_d9833.html#a959b40e8914d47343e24c002169c7cfe", null ],
    [ "setActivePhase", "class_m_d___a_d9833.html#a0b64736e63aa654bede19358cca3588c", null ],
    [ "setFrequency", "class_m_d___a_d9833.html#a8c441358f85c08270271603c4bd698a3", null ],
    [ "setMode", "class_m_d___a_d9833.html#a57b4c240384f25a9bc06a65d5d1901e7", null ],
    [ "setPhase", "class_m_d___a_d9833.html#a6cffbcec042d5eee2a18b84c5ce25552", null ]
];